export default function Starfield() {
  return <div className="starfield"></div>;
}
